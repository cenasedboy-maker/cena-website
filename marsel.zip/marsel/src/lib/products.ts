// Central product catalog for MARSEL STORE DIGITAL
// All prices are in Indonesian Rupiah (IDR)
// Variants represent duration tiers / account types

export type ProductVariant = {
  label: string;
  price: number; // IDR
  note?: string;
};

export type Product = {
  id: string;
  name: string;
  category: CategoryId;
  emoji: string;
  tagline: string;
  description: string;
  featured?: boolean;
  variants: ProductVariant[];
};

export type CategoryId =
  | "editing"
  | "ai"
  | "streaming"
  | "music"
  | "vpn"
  | "imei"
  | "robux";

export type Category = {
  id: CategoryId;
  label: string;
  emoji: string;
  blurb: string;
};

export const CATEGORIES: Category[] = [
  {
    id: "editing",
    label: "Editing & Photo",
    emoji: "🎨",
    blurb: "CapCut, Canva, Alight Motion, VSCO, dan lainnya",
  },
  {
    id: "ai",
    label: "AI Tools",
    emoji: "🤖",
    blurb: "ChatGPT, Claude, Gemini, Leonardo AI",
  },
  {
    id: "streaming",
    label: "Streaming Film",
    emoji: "🎬",
    blurb: "Netflix, Disney+, iQiyi, WeTV, HBO Max",
  },
  {
    id: "music",
    label: "Music & Drama",
    emoji: "🎵",
    blurb: "Spotify, Apple Music, YouTube Music, Viki",
  },
  {
    id: "vpn",
    label: "VPN & Productivity",
    emoji: "🛡️",
    blurb: "VPN, Microsoft 365, iCloud, Zoom, Email",
  },
  {
    id: "imei",
    label: "IMEI Unlock",
    emoji: "📱",
    blurb: "Buka pemblokiran IMEI untuk semua operator",
  },
  {
    id: "robux",
    label: "Robux Roblox",
    emoji: "🎮",
    blurb: "Robux super fast 10–15 menit",
  },
];

export const WHATSAPP_NUMBER = "6282148461770"; // +62 821-4846-1770
export const STORE_NAME = "Marsel Store Digital";

export const PRODUCTS: Product[] = [
  // ---------------- EDITING ----------------
  {
    id: "capcut",
    name: "CapCut Pro",
    category: "editing",
    emoji: "🎬",
    tagline: "Video editing tanpa watermark",
    description:
      "CapCut Pro resmi untuk membuat video cinematic tanpa watermark. Garansi penuh selama masa aktif.",
    featured: true,
    variants: [
      { label: "7 Hari", price: 6000 },
      { label: "1 Bulan (Member)", price: 23000 },
      { label: "42 Hari", price: 25000 },
    ],
  },
  {
    id: "canva",
    name: "Canva Pro",
    category: "editing",
    emoji: "🖌️",
    tagline: "Design toolkit lengkap",
    description:
      "Canva Pro dengan akses template premium, element, dan export HD.",
    featured: true,
    variants: [
      { label: "7 Hari", price: 3000 },
      { label: "1 Bulan", price: 5000 },
      { label: "1 Tahun", price: 7000 },
    ],
  },
  {
    id: "wink-android",
    name: "Wink Android",
    category: "editing",
    emoji: "✨",
    tagline: "Retouch wajah AI premium",
    description: "Wink versi Android untuk retouch wajah & video portrait.",
    variants: [
      { label: "1 Minggu", price: 7000 },
      { label: "1 Bulan", price: 18000 },
    ],
  },
  {
    id: "wink-ios",
    name: "Wink iOS",
    category: "editing",
    emoji: "📲",
    tagline: "Wink untuk iPhone",
    description: "Wink versi iOS / iPhone untuk retouch premium.",
    variants: [
      { label: "1 Minggu", price: 9000 },
      { label: "2 Minggu", price: 14000 },
    ],
  },
  {
    id: "meitu",
    name: "Meitu Premium",
    category: "editing",
    emoji: "📷",
    tagline: "Beauty & photo editor",
    description: "Meitu premium Android / iOS private version.",
    variants: [
      { label: "7 Hari", price: 10000 },
      { label: "14 Hari", price: 15000 },
    ],
  },
  {
    id: "winkit",
    name: "Winkit",
    category: "editing",
    emoji: "🌟",
    tagline: "AI photo enhancer",
    description: "Winkit untuk enhance foto HD dengan AI.",
    variants: [
      { label: "3 Hari", price: 7000 },
      { label: "9 Hari", price: 12000 },
    ],
  },
  {
    id: "beautyplus",
    name: "BeautyPlus",
    category: "editing",
    emoji: "💄",
    tagline: "Selfie beauty camera",
    description: "BeautyPlus premium untuk selfie & beauty camera.",
    variants: [
      { label: "7 Hari", price: 10000 },
      { label: "1 Bulan", price: 22000 },
    ],
  },
  {
    id: "alight-motion",
    name: "Alight Motion",
    category: "editing",
    emoji: "🎞️",
    tagline: "Motion graphics pro",
    description: "Alight Motion sharing atau private untuk motion graphics.",
    variants: [
      { label: "Sharing 1 Tahun", price: 4000 },
      { label: "Private 1 Tahun", price: 7000 },
    ],
  },
  {
    id: "keyflow",
    name: "Keyflow Mod",
    category: "editing",
    emoji: "🔑",
    tagline: "Android modified",
    description: "Keyflow versi modified untuk Android.",
    variants: [{ label: "1 Bulan", price: 14000 }],
  },
  {
    id: "efiko",
    name: "Efiko",
    category: "editing",
    emoji: "🎚️",
    tagline: "Pro editing tools",
    description: "Efiko premium untuk editing profesional.",
    variants: [{ label: "3 Bulan", price: 17000 }],
  },
  {
    id: "picsart",
    name: "Picsart Gold",
    category: "editing",
    emoji: "🖼️",
    tagline: "All-in-one photo editor",
    description: "Picsart Gold sharing atau private.",
    variants: [
      { label: "Sharing 1 Bulan", price: 10000 },
      { label: "Private 1 Bulan", price: 17000 },
    ],
  },
  {
    id: "polar",
    name: "Polar",
    category: "editing",
    emoji: "❄️",
    tagline: "Photo filter pro",
    description: "Polar premium 1 tahun.",
    variants: [{ label: "1 Tahun", price: 12000 }],
  },
  {
    id: "vsco",
    name: "VSCO",
    category: "editing",
    emoji: "🌑",
    tagline: "Film-style presets",
    description: "VSCO membership 1 tahun untuk filter film premium.",
    variants: [{ label: "1 Tahun", price: 17000 }],
  },
  {
    id: "ibis-paint",
    name: "Ibis Paint X",
    category: "editing",
    emoji: "🖌",
    tagline: "Drawing app premium",
    description: "Ibis Paint X premium 1 tahun.",
    variants: [{ label: "1 Tahun", price: 17000 }],
  },
  {
    id: "godnotes",
    name: "GodNotes iOS",
    category: "editing",
    emoji: "📓",
    tagline: "Aesthetic notes app",
    description: "GodNotes versi iOS premium 1 tahun.",
    variants: [{ label: "1 Tahun", price: 17000 }],
  },
  {
    id: "camscanner",
    name: "CamScanner",
    category: "editing",
    emoji: "📄",
    tagline: "PDF scanner pro",
    description: "CamScanner premium 1 tahun untuk scan dokumen HD.",
    variants: [{ label: "1 Tahun", price: 17000 }],
  },
  {
    id: "dazzcam",
    name: "DazzCam iOS",
    category: "editing",
    emoji: "📸",
    tagline: "Retro film camera",
    description: "DazzCam versi iOS 1 tahun untuk foto retro.",
    variants: [{ label: "1 Tahun (iOS)", price: 17000 }],
  },
  {
    id: "oldroll",
    name: "OldRoll",
    category: "editing",
    emoji: "📼",
    tagline: "Vintage camera pro",
    description: "OldRoll premium 1 tahun.",
    variants: [{ label: "1 Tahun", price: 12000 }],
  },
  {
    id: "remini",
    name: "Remini Web",
    category: "editing",
    emoji: "🔍",
    tagline: "AI photo restore",
    description: "Remini Web sharing atau private untuk restore foto.",
    variants: [
      { label: "Sharing 1 Bulan", price: 8000 },
      { label: "Private 1 Bulan", price: 15000 },
    ],
  },
  {
    id: "kilonotes",
    name: "KiloNotes Android",
    category: "editing",
    emoji: "📝",
    tagline: "Note-taking premium",
    description: "KiloNotes versi Android premium 1 tahun.",
    variants: [{ label: "1 Tahun", price: 17000 }],
  },
  {
    id: "getcontact",
    name: "Getcontact",
    category: "editing",
    emoji: "📞",
    tagline: "Caller ID premium",
    description: "Getcontact private 1 bulan.",
    variants: [{ label: "Private 1 Bulan", price: 12000 }],
  },
  {
    id: "wattpad",
    name: "Wattpad Premium",
    category: "editing",
    emoji: "📚",
    tagline: "Ad-free reading",
    description: "Wattpad Premium sharing atau private.",
    variants: [
      { label: "Sharing 1 Bulan", price: 10000 },
      { label: "Private 7 Hari", price: 8000 },
      { label: "Private 1 Bulan", price: 15000 },
    ],
  },
  {
    id: "duolingo",
    name: "Duolingo Super",
    category: "editing",
    emoji: "🦜",
    tagline: "Language learning pro",
    description: "Duolingo Super untuk belajar bahasa tanpa iklan.",
    variants: [
      { label: "Individual 2 Bulan", price: 7000 },
      { label: "Family 2 Bulan", price: 10000 },
    ],
  },
  {
    id: "scribd",
    name: "Scribd",
    category: "editing",
    emoji: "📑",
    tagline: "Books & documents",
    description: "Scribd private 1 bulan untuk akses buku & dokumen.",
    variants: [{ label: "Private 1 Bulan", price: 6000 }],
  },

  // ---------------- AI ----------------
  {
    id: "chatgpt-go",
    name: "ChatGPT GO",
    category: "ai",
    emoji: "💬",
    tagline: "AI chat cepat & murah",
    description: "ChatGPT GO sharing atau private untuk chatbot AI.",
    featured: true,
    variants: [
      { label: "Sharing 7 Hari", price: 10000 },
      { label: "Sharing 1 Bulan", price: 20000 },
      { label: "Sharing 1 Bulan Premium", price: 27000 },
      { label: "Private 1 Bulan", price: 47000 },
    ],
  },
  {
    id: "chatgpt-plus",
    name: "ChatGPT Plus",
    category: "ai",
    emoji: "⚡",
    tagline: "GPT-4 / GPT-4o",
    description: "ChatGPT Plus dengan model GPT-4 / GPT-4o.",
    featured: true,
    variants: [
      { label: "Sharing 1 Bulan", price: 22000 },
      { label: "Sharing 1 Bulan Premium", price: 30000 },
      { label: "Private 1 Bulan", price: 50000 },
    ],
  },
  {
    id: "chatgpt-pro",
    name: "ChatGPT Pro",
    category: "ai",
    emoji: "🚀",
    tagline: "Tier tertinggi OpenAI",
    description: "ChatGPT Pro tier tertinggi dengan limit tertinggi.",
    variants: [
      { label: "Sharing 1 Bulan", price: 30000 },
      { label: "Sharing 1 Bulan Premium", price: 32000 },
      { label: "Private 1 Bulan", price: 52000 },
    ],
  },
  {
    id: "gemini-ai",
    name: "Gemini AI",
    category: "ai",
    emoji: "♊",
    tagline: "Google AI premium",
    description: "Gemini AI (Google) dengan opsi Google One 5TB.",
    variants: [
      { label: "1 Bulan", price: 8000 },
      { label: "3 Bulan", price: 15000 },
      { label: "18 Bulan (Google One 5TB)", price: 21000 },
    ],
  },
  {
    id: "chai-ai",
    name: "Chai AI",
    category: "ai",
    emoji: "🍵",
    tagline: "Chat AI characters",
    description: "Chai AI premium untuk roleplay & karakter AI.",
    variants: [{ label: "3 Hari", price: 7000 }],
  },
  {
    id: "qanda",
    name: "QANDA",
    category: "ai",
    emoji: "📘",
    tagline: "AI solver matematika",
    description: "QANDA premium untuk bantu kerjakan soal.",
    variants: [{ label: "1 Bulan", price: 27000 }],
  },
  {
    id: "claude-ai",
    name: "Claude AI",
    category: "ai",
    emoji: "🧠",
    tagline: "Anthropic Claude Pro",
    description: "Claude AI Pro dari Anthropic untuk writing & analisis.",
    featured: true,
    variants: [
      { label: "Sharing 7 Hari", price: 43000 },
      { label: "Sharing 1 Bulan", price: 98000 },
      { label: "Sharing 3 Bulan", price: 118000 },
    ],
  },
  {
    id: "grok-ai",
    name: "Grok AI",
    category: "ai",
    emoji: "🛰️",
    tagline: "xAI Grok",
    description: "Grok AI dari xAI premium.",
    variants: [{ label: "7 Hari", price: 9000 }],
  },
  {
    id: "china-api",
    name: "China Model API",
    category: "ai",
    emoji: "🧧",
    tagline: "Token AI massal",
    description: "API model China dengan paket token 50M–500M.",
    variants: [
      { label: "50M Token", price: 20000 },
      { label: "100M Token", price: 40000 },
      { label: "500M Token", price: 160000 },
    ],
  },
  {
    id: "leonardo-ai",
    name: "Leonardo AI",
    category: "ai",
    emoji: "🎨",
    tagline: "AI image generator",
    description: "Leonardo AI untuk generate gambar dengan AI.",
    variants: [
      { label: "8.500 Token", price: 14000 },
      { label: "110K Token (Paket Besar)", price: 0, note: "Harga hubungi admin" },
    ],
  },
  {
    id: "adobe-express",
    name: "Adobe Express",
    category: "ai",
    emoji: "🔺",
    tagline: "Adobe design simple",
    description: "Adobe Express premium 1 tahun.",
    variants: [{ label: "1 Tahun", price: 14000 }],
  },
  {
    id: "photoroom",
    name: "PhotoRoom",
    category: "ai",
    emoji: "🖼",
    tagline: "AI background remover",
    description: "PhotoRoom private untuk hapus background AI.",
    variants: [{ label: "Private 7 Hari", price: 5000 }],
  },

  // ---------------- STREAMING (FILM) ----------------
  {
    id: "netflix",
    name: "Netflix Premium",
    category: "streaming",
    emoji: "🍿",
    tagline: "Film & serial tanpa iklan",
    description: "Netflix Premium sharing / private. Quality 4K UHD.",
    featured: true,
    variants: [
      { label: "Sharing 1 Minggu 3 Hari", price: 7000 },
      { label: "Sharing 1 Bulan", price: 32000 },
      { label: "Private 1 Bulan", price: 165000 },
    ],
  },
  {
    id: "youtube-family",
    name: "YouTube Family",
    category: "streaming",
    emoji: "▶️",
    tagline: "YouTube Premium share",
    description: "YouTube Premium family plan sharing.",
    variants: [{ label: "1 Bulan", price: 6000 }],
  },
  {
    id: "vidio",
    name: "Vidio",
    category: "streaming",
    emoji: "📡",
    tagline: "Streaming lokal & olahraga",
    description: "Vidio private untuk live sport & series lokal.",
    variants: [{ label: "Private 1 Bulan", price: 24000 }],
  },
  {
    id: "iqiyi",
    name: "iQiyi VIP",
    category: "streaming",
    emoji: "🇨🇳",
    tagline: "Drama China premium",
    description: "iQiyi VIP sharing atau private.",
    variants: [
      { label: "Sharing 1 Bulan", price: 6000 },
      { label: "Private 1 Bulan", price: 32000 },
    ],
  },
  {
    id: "bstation",
    name: "Bstation (Bilibili)",
    category: "streaming",
    emoji: "📺",
    tagline: "Anime & creator platform",
    description: "Bstation premium sharing 1 bulan.",
    variants: [{ label: "Sharing 1 Bulan", price: 7000 }],
  },
  {
    id: "wetv",
    name: "WeTV VIP",
    category: "streaming",
    emoji: "🎭",
    tagline: "Drama Asia tanpa iklan",
    description: "WeTV VIP sharing atau private.",
    variants: [
      { label: "Sharing 1 Bulan", price: 8000 },
      { label: "Private 1 Bulan", price: 24000 },
    ],
  },
  {
    id: "prime-amazon",
    name: "Amazon Prime",
    category: "streaming",
    emoji: "📦",
    tagline: "Prime Video sharing",
    description: "Amazon Prime Video sharing 1 bulan.",
    variants: [{ label: "Sharing 1 Bulan", price: 4000 }],
  },
  {
    id: "youku",
    name: "Youku VIP",
    category: "streaming",
    emoji: "🎞",
    tagline: "Streaming China",
    description: "Youku VIP sharing 1 bulan.",
    variants: [{ label: "Sharing 1 Bulan", price: 6000 }],
  },
  {
    id: "hbo-max",
    name: "HBO Max",
    category: "streaming",
    emoji: "🎥",
    tagline: "Original series premium",
    description: "HBO Max sharing atau private.",
    variants: [
      { label: "Sharing 1 Bulan", price: 10000 },
      { label: "Private 1 Bulan", price: 40000 },
    ],
  },
  {
    id: "viu",
    name: "Viu Premium",
    category: "streaming",
    emoji: "🌍",
    tagline: "Drama Korea & Asia",
    description: "Viu Premium 1 bulan untuk drakor & variety show.",
    variants: [{ label: "1 Bulan", price: 2000 }],
  },
  {
    id: "disney",
    name: "Disney+ Hotstar",
    category: "streaming",
    emoji: "🏰",
    tagline: "Disney, Marvel, Star Wars",
    description: "Disney+ Hotstar sharing mulai 13K.",
    variants: [{ label: "Sharing 1 Bulan", price: 13000 }],
  },
  {
    id: "loklok",
    name: "Loklok",
    category: "streaming",
    emoji: "🔁",
    tagline: "Streaming multibahasa",
    description: "Loklok streaming sharing 15K.",
    variants: [{ label: "Sharing", price: 15000 }],
  },

  // ---------------- MUSIC / DRAMA ----------------
  {
    id: "viki-rakuten",
    name: "Rakuten Viki Plus",
    category: "music",
    emoji: "📺",
    tagline: "Drama Asia subtitle",
    description: "Rakuten Viki Plus sharing atau private.",
    variants: [
      { label: "Sharing 1 Bulan", price: 10000 },
      { label: "Private 1 Bulan", price: 32000 },
    ],
  },
  {
    id: "drama-box",
    name: "Drama Box",
    category: "music",
    emoji: "📦",
    tagline: "Short drama streaming",
    description: "Drama Box sharing 1 bulan.",
    variants: [{ label: "Sharing 1 Bulan", price: 14000 }],
  },
  {
    id: "melolo",
    name: "Melolo",
    category: "music",
    emoji: "🎧",
    tagline: "Audio drama streaming",
    description: "Melolo sharing 1 bulan.",
    variants: [{ label: "Sharing 1 Bulan", price: 12000 }],
  },
  {
    id: "vision-bein",
    name: "Vision+ Bein Sport",
    category: "music",
    emoji: "⚽",
    tagline: "Live sport premium",
    description: "Vision+ Bein Sport private untuk live olahraga.",
    variants: [{ label: "Private 1 Bulan", price: 16000 }],
  },
  {
    id: "crunchyroll",
    name: "Crunchyroll",
    category: "music",
    emoji: "🐉",
    tagline: "Anime premium",
    description: "Crunchyroll premium sharing 1 tahun.",
    variants: [{ label: "Sharing 1 Tahun", price: 10000 }],
  },
  {
    id: "gagaoolala",
    name: "GagaOOLala",
    category: "music",
    emoji: "🌈",
    tagline: "LGBTQ+ streaming",
    description: "GagaOOLala sharing 1 bulan.",
    variants: [{ label: "Sharing 1 Bulan", price: 9000 }],
  },
  {
    id: "mango-tv",
    name: "Mango TV VIP",
    category: "music",
    emoji: "🥭",
    tagline: "Variety & drama China",
    description: "Mango TV VIP sharing 1 bulan.",
    variants: [{ label: "Sharing 1 Bulan", price: 6000 }],
  },
  {
    id: "grammarly",
    name: "Grammarly Pro",
    category: "music",
    emoji: "✍️",
    tagline: "Writing assistant AI",
    description: "Grammarly Pro untuk koreksi grammar.",
    variants: [
      { label: "7 Hari", price: 6000 },
      { label: "14 Hari", price: 9000 },
    ],
  },
  {
    id: "reelshort",
    name: "Reel Short",
    category: "music",
    emoji: "📱",
    tagline: "Short drama VIP",
    description: "Reel Short Basic VIP 1 bulan.",
    variants: [{ label: "Basic VIP 1 Bulan", price: 13000 }],
  },
  {
    id: "spotify",
    name: "Spotify Premium",
    category: "music",
    emoji: "🎶",
    tagline: "Music streaming tanpa iklan",
    description: "Spotify Premium family atau individual.",
    featured: true,
    variants: [
      { label: "Family 1 Bulan", price: 19000 },
      { label: "Family 2 Bulan", price: 29000 },
      { label: "Individual 1 Bulan", price: 21000 },
      { label: "Individual 2 Bulan", price: 33000 },
    ],
  },
  {
    id: "apple-music",
    name: "Apple Music",
    category: "music",
    emoji: "🍎",
    tagline: "Lossless audio",
    description: "Apple Music family iOS / individual Android.",
    variants: [
      { label: "iOS Family 1 Bulan", price: 6000 },
      { label: "iOS Family 2 Bulan", price: 9000 },
      { label: "Android Individual 1 Bulan", price: 10000 },
    ],
  },
  {
    id: "youtube-music",
    name: "YouTube Music",
    category: "music",
    emoji: "🎵",
    tagline: "Music + video mix",
    description: "YouTube Music Premium family / individual.",
    variants: [
      { label: "Family", price: 12000 },
      { label: "Individual", price: 14000 },
    ],
  },

  // ---------------- VPN / PRODUCTIVITY ----------------
  {
    id: "quillbot",
    name: "Quillbot Premium",
    category: "vpn",
    emoji: "📝",
    tagline: "AI paraphraser",
    description: "Quillbot premium sharing untuk paraphrase & writing.",
    variants: [{ label: "Sharing 1 Bulan", price: 13000 }],
  },
  {
    id: "turbo-vpn",
    name: "Turbo VPN",
    category: "vpn",
    emoji: "⚡",
    tagline: "VPN private cepat",
    description: "Turbo VPN private 7 hari.",
    variants: [{ label: "Private 7 Hari", price: 5000 }],
  },
  {
    id: "icloud-2tb",
    name: "iCloud 2TB",
    category: "vpn",
    emoji: "☁️",
    tagline: "Apple One bundle",
    description:
      "iCloud 2TB sharing termasuk Apple Music, TV+, Fitness+, Arcade. Kapasitas 400GB/orang.",
    variants: [{ label: "Sharing 2 Bulan", price: 58000 }],
  },
  {
    id: "ms365-invite",
    name: "MS 365 Invite",
    category: "vpn",
    emoji: "📧",
    tagline: "Office 365 sharing",
    description: "Microsoft 365 sharing invite 1 bulan.",
    variants: [
      { label: "Invite 1 Bulan", price: 7000 },
      { label: "Manager 1 Bulan", price: 12000 },
    ],
  },
  {
    id: "avira-vpn",
    name: "Avira VPN",
    category: "vpn",
    emoji: "🛡",
    tagline: "VPN private 3 bulan",
    description: "Avira Phantom VPN private 3 bulan.",
    variants: [{ label: "Private 3 Bulan", price: 5000 }],
  },
  {
    id: "ms-office-365",
    name: "Microsoft Office 365",
    category: "vpn",
    emoji: "📊",
    tagline: "Word Excel PPT private",
    description: "Microsoft Office 365 private 1 bulan.",
    variants: [{ label: "Private 1 Bulan", price: 8000 }],
  },
  {
    id: "surfshark",
    name: "Surfshark VPN",
    category: "vpn",
    emoji: "🦈",
    tagline: "Unlimited devices",
    description: "Surfshark VPN 2 bulan.",
    variants: [{ label: "2 Bulan", price: 20000 }],
  },
  {
    id: "hma-vpn",
    name: "HMA VPN",
    category: "vpn",
    emoji: "🥷",
    tagline: "VPN dengan banyak server",
    description: "HMA VPN 1 bulan.",
    variants: [{ label: "1 Bulan", price: 6000 }],
  },
  {
    id: "zoom-meeting",
    name: "Zoom Pro",
    category: "vpn",
    emoji: "🎥",
    tagline: "Meeting 30 jam",
    description: "Zoom Meeting Professional 7 / 14 hari.",
    variants: [
      { label: "Pro 7 Hari", price: 4000 },
      { label: "Pro 14 Hari", price: 7000 },
    ],
  },
  {
    id: "express-vpn",
    name: "Express VPN",
    category: "vpn",
    emoji: "🚀",
    tagline: "VPN cepat global",
    description: "Express VPN 3 hari trial.",
    variants: [{ label: "3 Hari", price: 4000 }],
  },
  {
    id: "outlook-email",
    name: "Outlook / Hotmail Email",
    category: "vpn",
    emoji: "✉️",
    tagline: "Email baru verified",
    description: "Akun Outlook / Hotmail baru verified.",
    variants: [
      { label: "Hotmail Baru", price: 5000 },
      { label: "Outlook Baru", price: 5000 },
    ],
  },
  {
    id: "muse-ai",
    name: "Muse AI",
    category: "vpn",
    emoji: "🎭",
    tagline: "AI video generator",
    description: "Muse AI 1 miliar token.",
    variants: [{ label: "1 Miliar Token", price: 10000 }],
  },

  // ---------------- IMEI ----------------
  {
    id: "imei-fast",
    name: "IMEI Unlock — FAST",
    category: "imei",
    emoji: "📱",
    tagline: "Selesai 1–3 jam",
    description:
      "Buka pemblokiran IMEI semua operator Android / iPhone. Garansi 3 bulan, proses 100% online. Selesai 1–3 jam.",
    featured: true,
    variants: [{ label: "FAST (1–3 Jam)", price: 170000 }],
  },
  {
    id: "imei-slow",
    name: "IMEI Unlock — SLOW",
    category: "imei",
    emoji: "📲",
    tagline: "Selesai dalam 24 jam",
    description:
      "Buka pemblokiran IMEI semua operator Android / iPhone. Garansi 3 bulan, proses 100% online. Selesai dalam 24 jam.",
    variants: [{ label: "SLOW (24 Jam)", price: 155000 }],
  },
  {
    id: "imei-check",
    name: "Cek Status IMEI",
    category: "imei",
    emoji: "🔍",
    tagline: "Cek status pemblokiran",
    description:
      "Cek status IMEI terblokir atau aktif. Kirim screenshot IMEI dari *#06#.",
    variants: [{ label: "Cek Status", price: 15000 }],
  },

  // ---------------- ROBUX ----------------
  {
    id: "robux-80",
    name: "Robux 80",
    category: "robux",
    emoji: "💎",
    tagline: "Roblox currency",
    description: "Top up Robux Roblox super fast 10–15 menit.",
    variants: [{ label: "80 Robux", price: 20000 }],
  },
  {
    id: "robux-160",
    name: "Robux 160",
    category: "robux",
    emoji: "💎",
    tagline: "Roblox currency",
    description: "Top up Robux Roblox super fast 10–15 menit.",
    variants: [{ label: "160 Robux", price: 35000 }],
  },
  {
    id: "robux-240",
    name: "Robux 240",
    category: "robux",
    emoji: "💎",
    tagline: "Roblox currency",
    description: "Top up Robux Roblox super fast 10–15 menit.",
    variants: [{ label: "240 Robux", price: 50000 }],
  },
  {
    id: "robux-320",
    name: "Robux 320",
    category: "robux",
    emoji: "💎",
    tagline: "Roblox currency",
    description: "Top up Robux Roblox super fast 10–15 menit.",
    variants: [{ label: "320 Robux", price: 65000 }],
  },
  {
    id: "robux-500",
    name: "Robux 500",
    category: "robux",
    emoji: "💎",
    tagline: "Roblox currency",
    description: "Top up Robux Roblox super fast 10–15 menit.",
    variants: [{ label: "500 Robux", price: 78000 }],
  },
  {
    id: "robux-1000",
    name: "Robux 1.000",
    category: "robux",
    emoji: "💎",
    tagline: "Roblox currency",
    description: "Top up Robux Roblox super fast 10–15 menit.",
    featured: true,
    variants: [{ label: "1.000 Robux", price: 155000 }],
  },
  {
    id: "robux-2000",
    name: "Robux 2.000",
    category: "robux",
    emoji: "💎",
    tagline: "Roblox currency",
    description: "Top up Robux Roblox super fast 10–15 menit.",
    variants: [{ label: "2.000 Robux", price: 305000 }],
  },
  {
    id: "robux-5000",
    name: "Robux 5.000",
    category: "robux",
    emoji: "💎",
    tagline: "Roblox currency",
    description: "Top up Robux Roblox super fast 10–15 menit.",
    variants: [{ label: "5.000 Robux", price: 744000 }],
  },
  {
    id: "robux-10000",
    name: "Robux 10.000",
    category: "robux",
    emoji: "💎",
    tagline: "Roblox currency — paket besar",
    description: "Top up Robux Roblox super fast 10–15 menit.",
    variants: [{ label: "10.000 Robux", price: 1480000 }],
  },
];

export function formatIDR(n: number): string {
  if (n === 0) return "Hubungi Admin";
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(n);
}

export function buildWhatsAppOrderMessage(opts: {
  productName: string;
  variantLabel: string;
  price: number;
  storeName?: string;
}): string {
  const store = opts.storeName ?? STORE_NAME;
  const priceText =
    opts.price === 0 ? "harga hubungi admin" : `Rp ${opts.price.toLocaleString("id-ID")}`;
  const msg =
    `Halo *${store}*, saya ingin memesan produk berikut:\n\n` +
    `• Produk : ${opts.productName}\n` +
    `• Paket  : ${opts.variantLabel}\n` +
    `• Harga  : ${priceText}\n\n` +
    `Saya sudah/siap melakukan pembayaran via QRIS. Mohon konfirmasi pesanan saya dan panduan selanjutnya. Terima kasih 🙏`;
  return msg;
}

export function buildWhatsAppGeneralMessage(text: string): string {
  return encodeURIComponent(text);
}

export function whatsappLink(message: string): string {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}
