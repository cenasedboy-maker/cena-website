"use client";

import { useMemo } from "react";

type Props = {
  /** number of floating particles */
  particleCount?: number;
  /** enable slow aurora blobs */
  aurora?: boolean;
  /** enable drifting particles */
  particles?: boolean;
  className?: string;
};

/**
 * Layered animated background:
 * - Animated grid (with radial mask)
 * - Slow-drifting aurora blobs
 * - Floating particles rising upward
 */
export function AnimatedBackground({
  particleCount = 18,
  aurora = true,
  particles = true,
  className = "",
}: Props) {
  const particleData = useMemo(
    () =>
      Array.from({ length: particleCount }).map((_, i) => {
        const size = Math.random() * 2 + 1; // 1-3px
        const left = Math.random() * 100; // %
        const delay = Math.random() * 18; // s
        const duration = 14 + Math.random() * 12; // 14-26s
        const drift = (Math.random() - 0.5) * 80; // -40 to +40px
        const opacity = 0.25 + Math.random() * 0.4; // 0.25-0.65
        return { i, size, left, delay, duration, drift, opacity };
      }),
    [particleCount],
  );

  return (
    <div
      className={`pointer-events-none absolute inset-0 -z-10 overflow-hidden ${className}`}
      aria-hidden
    >
      {/* Animated grid */}
      <div className="absolute inset-0 bg-grid bg-grid-fade opacity-50" />

      {/* Aurora gradient mesh blobs */}
      {aurora && (
        <>
          <div
            className="aurora-blob"
            style={{
              top: "5%",
              left: "10%",
              width: "40vw",
              height: "40vw",
              maxWidth: "520px",
              maxHeight: "520px",
              background:
                "radial-gradient(circle at center, rgba(255,255,255,0.10), transparent 70%)",
            }}
          />
          <div
            className="aurora-blob aurora-blob-2"
            style={{
              top: "30%",
              right: "5%",
              width: "32vw",
              height: "32vw",
              maxWidth: "420px",
              maxHeight: "420px",
              background:
                "radial-gradient(circle at center, rgba(255,255,255,0.08), transparent 70%)",
            }}
          />
          <div
            className="aurora-blob aurora-blob-3"
            style={{
              bottom: "0%",
              left: "30%",
              width: "36vw",
              height: "36vw",
              maxWidth: "480px",
              maxHeight: "480px",
              background:
                "radial-gradient(circle at center, rgba(255,255,255,0.06), transparent 70%)",
            }}
          />
        </>
      )}

      {/* Floating particles rising */}
      {particles && (
        <div className="absolute inset-0">
          {particleData.map((p) => (
            <span
              key={p.i}
              className="particle-float"
              style={
                {
                  left: `${p.left}%`,
                  bottom: "-10px",
                  width: `${p.size}px`,
                  height: `${p.size}px`,
                  animationDelay: `${p.delay}s`,
                  "--p-duration": `${p.duration}s`,
                  "--p-drift": `${p.drift}px`,
                  "--p-opacity": p.opacity,
                } as React.CSSProperties
              }
            />
          ))}
        </div>
      )}

      {/* Grain overlay */}
      <div className="absolute inset-0 grain-overlay opacity-25" />

      {/* Vignette for depth */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 100% 60% at 50% 100%, rgba(0,0,0,0.45), transparent 60%)",
        }}
      />
    </div>
  );
}
