"use client";

import { useMemo } from "react";

/**
 * Site-wide fixed-position animated background.
 * - Subtle animated grid
 * - Slow-drifting aurora gradient blobs
 * - Floating particles rising across the viewport
 *
 * Sits behind everything (z-index -10), pointer-events-none.
 */
export function GlobalBackground() {
  // Generate particles once
  const particles = useMemo(
    () =>
      Array.from({ length: 16 }).map((_, i) => {
        const size = Math.random() * 2 + 1;
        const left = Math.random() * 100;
        const delay = Math.random() * 22;
        const duration = 18 + Math.random() * 14;
        const drift = (Math.random() - 0.5) * 100;
        const opacity = 0.18 + Math.random() * 0.3;
        return { i, size, left, delay, duration, drift, opacity };
      }),
    [],
  );

  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
    >
      {/* Soft base gradient */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 80% 50% at 20% 0%, rgba(255,255,255,0.04), transparent 60%), radial-gradient(ellipse 80% 50% at 80% 100%, rgba(255,255,255,0.03), transparent 60%)",
        }}
      />

      {/* Animated grid (subtle) */}
      <div className="absolute inset-0 bg-grid opacity-[0.18] [mask-image:radial-gradient(ellipse_70%_60%_at_50%_30%,black_30%,transparent_80%)]" />

      {/* Aurora blobs */}
      <div
        className="aurora-blob"
        style={{
          top: "10%",
          left: "5%",
          width: "40vw",
          height: "40vw",
          maxWidth: "520px",
          maxHeight: "520px",
          background:
            "radial-gradient(circle at center, rgba(255,255,255,0.08), transparent 70%)",
        }}
      />
      <div
        className="aurora-blob aurora-blob-2"
        style={{
          top: "45%",
          right: "0%",
          width: "32vw",
          height: "32vw",
          maxWidth: "420px",
          maxHeight: "420px",
          background:
            "radial-gradient(circle at center, rgba(255,255,255,0.07), transparent 70%)",
        }}
      />
      <div
        className="aurora-blob aurora-blob-3"
        style={{
          bottom: "5%",
          left: "30%",
          width: "36vw",
          height: "36vw",
          maxWidth: "480px",
          maxHeight: "480px",
          background:
            "radial-gradient(circle at center, rgba(255,255,255,0.05), transparent 70%)",
        }}
      />

      {/* Floating particles */}
      {particles.map((p) => (
        <span
          key={p.i}
          className="particle-float"
          style={
            {
              left: `${p.left}%`,
              bottom: "-10px",
              width: `${p.size}px`,
              height: `${p.size}px`,
              animationDelay: `${p.delay}s`,
              "--p-duration": `${p.duration}s`,
              "--p-drift": `${p.drift}px`,
              "--p-opacity": p.opacity,
            } as React.CSSProperties
          }
        />
      ))}

      {/* Grain */}
      <div className="absolute inset-0 grain-overlay opacity-20" />
    </div>
  );
}
