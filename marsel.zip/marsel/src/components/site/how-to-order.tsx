"use client";

import { motion } from "framer-motion";
import {
  MousePointerClick,
  QrCode,
  MessageCircle,
  PackageCheck,
  ChevronRight,
} from "lucide-react";

const STEPS = [
  {
    icon: MousePointerClick,
    title: "Pilih Produk",
    desc: "Klik produk digital yang ingin kamu beli dari katalog kami.",
  },
  {
    icon: QrCode,
    title: "Bayar via QRIS",
    desc: "Scan QRIS yang muncul menggunakan e-wallet atau m-banking favoritmu.",
  },
  {
    icon: MessageCircle,
    title: "Konfirmasi WA",
    desc: "Klik tombol WhatsApp — pesan sudah otomatis berisi detail pesanan.",
  },
  {
    icon: PackageCheck,
    title: "Terima Akun",
    desc: "Admin akan memproses & mengirim akun / layanan dalam beberapa menit.",
  },
];

export function HowToOrder() {
  return (
    <section
      id="cara-pesan"
      className="relative py-16 sm:py-24 border-t border-white/5 scroll-mt-16 overflow-hidden"
    >
      {/* Decorative grid */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-grid bg-grid-fade opacity-30" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] uppercase tracking-wider text-white/65">
            <span className="h-1 w-1 rounded-full bg-white/40" />
            Cara Pemesanan
          </span>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl font-extrabold text-white text-layered" style={{ letterSpacing: "-0.02em" }}>
            Pesan dalam 4 langkah
          </h2>
          <p className="mt-3 text-sm text-white/55 max-w-xl mx-auto">
            Pembayaran QRIS otomatis &amp; konfirmasi WhatsApp sudah berisi
            detail lengkap — profesional &amp; tanpa repot.
          </p>
        </motion.div>

        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {STEPS.map((s, i) => {
            const Icon = s.icon;
            return (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                className="group relative rounded-2xl border border-white/5 bg-white/[0.02] p-5 hover:border-white/15 transition-colors overflow-hidden"
              >
                <div className="absolute -top-6 -right-6 h-20 w-20 rounded-full bg-white/[0.03] blur-2xl group-hover:bg-white/[0.06] transition-colors" />
                <div className="flex items-center justify-between">
                  <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-white/10 text-white group-hover:bg-white group-hover:text-black transition-all duration-300">
                    <Icon className="h-5 w-5" strokeWidth={1.75} />
                  </div>
                  <span className="font-display text-3xl font-bold text-white/10 group-hover:text-white/20 transition-colors">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </div>
                <h3 className="mt-3 font-display text-sm font-semibold text-white">
                  {s.title}
                </h3>
                <p className="mt-1 text-xs text-white/55 leading-relaxed">
                  {s.desc}
                </p>
                {i < STEPS.length - 1 && (
                  <div className="hidden lg:flex absolute top-1/2 -right-2 h-5 w-5 items-center justify-center">
                    <ChevronRight className="h-4 w-4 text-white/15" />
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
