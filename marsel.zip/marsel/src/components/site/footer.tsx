"use client";

import { motion } from "framer-motion";
import {
  MessageCircle,
  Clock,
  Mail,
  ShieldCheck,
  MapPin,
  QrCode,
  ChevronRight,
} from "lucide-react";
import { STORE_NAME, WHATSAPP_NUMBER, whatsappLink } from "@/lib/products";
import { CATEGORIES } from "@/lib/products";
import { CATEGORY_ICON } from "@/lib/icons";
import { Magnetic } from "./magnetic";

export function Footer() {
  const waDisplay = `+62 821-4846-1770`;
  return (
    <footer
      id="kontak"
      className="relative mt-auto border-t border-white/5 bg-gradient-to-b from-transparent to-white/[0.02] scroll-mt-16"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center gap-3">
              <span className="relative inline-flex h-10 w-10 items-center justify-center rounded-xl overflow-hidden ring-1 ring-white/15 shadow-[0_0_24px_rgba(255,255,255,0.12)]">
                <img
                  src="/marsel-logo.png"
                  alt="Marsel Store Digital logo"
                  className="w-full h-full object-cover"
                />
              </span>
              <div className="flex flex-col leading-tight">
                <span className="font-display font-bold text-sm tracking-wide text-white">
                  MARSEL STORE
                </span>
                <span className="text-[10px] uppercase tracking-[0.25em] text-white/45">
                  Digital
                </span>
              </div>
            </div>
            <p className="mt-4 text-sm text-white/55 leading-relaxed max-w-xs">
              Premium digital subscription store. Semua kebutuhan digitalmu —
              editing, AI, streaming, VPN, IMEI &amp; Robux — dalam satu tempat.
            </p>
            <div className="mt-4 inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-[11px] text-white/70">
              <ShieldCheck className="h-3.5 w-3.5" />
              Bergaransi &amp; terpercaya
            </div>
          </motion.div>

          {/* Contact */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.08 }}
          >
            <h3 className="font-display text-sm font-semibold text-white uppercase tracking-wider">
              Hubungi Kami
            </h3>
            <ul className="mt-4 space-y-3 text-sm">
              <li>
                <a
                  href={whatsappLink(
                    `Halo ${STORE_NAME}, saya ingin bertanya tentang produk digital.`,
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-3 text-white/65 hover:text-white transition-colors group"
                >
                  <MessageCircle className="h-4 w-4 mt-0.5 text-white/50 group-hover:text-white transition-colors" />
                  <span>
                    <span className="block text-xs text-white/45">WhatsApp</span>
                    {waDisplay}
                  </span>
                </a>
              </li>
              <li className="flex items-start gap-3 text-white/65">
                <Clock className="h-4 w-4 mt-0.5 text-white/50" />
                <span>
                  <span className="block text-xs text-white/45">Jam Operasional</span>
                  Setiap hari · 08.00 – 23.00 WIB
                </span>
              </li>
              <li className="flex items-start gap-3 text-white/65">
                <MapPin className="h-4 w-4 mt-0.5 text-white/50" />
                <span>
                  <span className="block text-xs text-white/45">Lokasi</span>
                  Indonesia · melayani seluruh Indonesia
                </span>
              </li>
              <li className="flex items-start gap-3 text-white/65">
                <QrCode className="h-4 w-4 mt-0.5 text-white/50" />
                <span>
                  <span className="block text-xs text-white/45">NMID QRIS</span>
                  ID1026597923998
                </span>
              </li>
            </ul>
          </motion.div>

          {/* Categories */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.16 }}
          >
            <h3 className="font-display text-sm font-semibold text-white uppercase tracking-wider">
              Kategori
            </h3>
            <ul className="mt-4 space-y-1.5 text-sm">
              {CATEGORIES.map((c) => {
                const Icon = CATEGORY_ICON[c.id];
                return (
                  <li key={c.id}>
                    <a
                      href={`#cat-${c.id}`}
                      className="group flex items-center gap-2.5 text-white/65 hover:text-white transition-colors py-1"
                    >
                      <span className="inline-flex h-7 w-7 items-center justify-center rounded-lg bg-white/5 border border-white/5 group-hover:bg-white group-hover:text-black transition-all">
                        <Icon className="h-3.5 w-3.5" />
                      </span>
                      {c.label}
                      <ChevronRight className="h-3 w-3 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                    </a>
                  </li>
                );
              })}
            </ul>
            <div className="mt-5">
              <Magnetic strength={0.25}>
                <a
                  href={whatsappLink(
                    `Halo ${STORE_NAME}, saya tertarik dengan produk digitalnya dan ingin bertanya.`,
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 h-10 px-4 rounded-lg bg-white text-black text-sm font-semibold hover:shadow-[0_0_24px_rgba(255,255,255,0.25)] transition-shadow"
                >
                  <MessageCircle className="h-4 w-4" />
                  Chat Admin
                </a>
              </Magnetic>
            </div>
          </motion.div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-white/40">
          <span>
            © {new Date().getFullYear()} {STORE_NAME}. All rights reserved.
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" />
            Made with care in Indonesia
          </span>
        </div>
      </div>
    </footer>
  );
}
