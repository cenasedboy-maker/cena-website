"use client";

import { motion } from "framer-motion";
import { LayoutGrid, ChevronRight } from "lucide-react";
import { CATEGORIES, type CategoryId } from "@/lib/products";
import { CATEGORY_ICON } from "@/lib/icons";

type Props = {
  active: CategoryId | "all";
  onChange: (id: CategoryId | "all") => void;
};

export function CategoryTabs({ active, onChange }: Props) {
  const tabs: Array<{ id: CategoryId | "all"; label: string; Icon: typeof LayoutGrid }> = [
    { id: "all", label: "Semua", Icon: LayoutGrid },
    ...CATEGORIES.map((c) => ({
      id: c.id,
      label: c.label,
      Icon: CATEGORY_ICON[c.id] ?? LayoutGrid,
    })),
  ];

  return (
    <div className="sticky top-16 z-30 -mx-4 px-4 py-3 sm:py-4 bg-background/85 backdrop-blur-xl border-b border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {tabs.map((tab) => {
            const isActive = active === tab.id;
            const Icon = tab.Icon;
            return (
              <button
                key={tab.id}
                onClick={() => onChange(tab.id as CategoryId | "all")}
                className={`relative shrink-0 inline-flex items-center gap-2 h-10 px-4 rounded-xl text-sm font-medium transition-colors ${
                  isActive
                    ? "text-black"
                    : "text-white/70 hover:text-white hover:bg-white/5"
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId="active-tab"
                    className="absolute inset-0 rounded-xl bg-white"
                    transition={{ type: "spring", stiffness: 380, damping: 32 }}
                  />
                )}
                <span className="relative z-10 flex items-center gap-2">
                  <Icon className="h-4 w-4" />
                  {tab.label}
                </span>
                {isActive && (
                  <ChevronRight className="relative z-10 h-3.5 w-3.5" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
