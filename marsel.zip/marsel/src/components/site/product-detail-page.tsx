"use client";

import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  Check,
  ChevronRight,
  ChevronLeft,
  QrCode,
  ShieldCheck,
  Copy,
  CheckCheck,
  MessageCircle,
  Loader2,
  Tag,
  Clock,
  Sparkles,
  ArrowRight,
} from "lucide-react";
import {
  type Product,
  type ProductVariant,
  formatIDR,
  buildWhatsAppOrderMessage,
  whatsappLink,
  STORE_NAME,
} from "@/lib/products";
import { getProductIcon } from "@/lib/icons";

type Props = {
  product: Product | null;
  open: boolean;
  onClose: () => void;
};

type Step = "select" | "pay" | "done";

export function ProductDetailPage({ product, open, onClose }: Props) {
  const [step, setStep] = useState<Step>("select");
  const [variant, setVariant] = useState<ProductVariant | null>(null);
  const [copied, setCopied] = useState(false);
  const [paying, setPaying] = useState(false);

  // Sync state when product changes — "adjust state during render" pattern
  const [lastProductId, setLastProductId] = useState<string | undefined>(
    product?.id,
  );
  if (open && product && product.id !== lastProductId) {
    setLastProductId(product.id);
    setVariant(product.variants[0] ?? null);
    setStep("select");
    setCopied(false);
    setPaying(false);
  }

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  const waLink = useMemo(() => {
    if (!product || !variant) return "";
    const msg = buildWhatsAppOrderMessage({
      productName: product.name,
      variantLabel: variant.label,
      price: variant.price,
    });
    return whatsappLink(msg);
  }, [product, variant]);

  const handleConfirmPayment = () => {
    setPaying(true);
    setTimeout(() => {
      setPaying(false);
      setStep("done");
    }, 800);
  };

  const copyOrderId = () => {
    const id = `MSD-${Date.now().toString().slice(-8)}`;
    navigator.clipboard?.writeText(id).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const Icon = product ? getProductIcon(product.id, product.category) : Sparkles;

  return (
    <AnimatePresence>
      {open && product && (
        <motion.div
          className="fixed inset-0 z-[60] flex items-stretch sm:items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
        >
          {/* Backdrop */}
          <motion.div
            className="absolute inset-0 bg-black/85 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Page-like sheet */}
          <motion.div
            initial={{ y: "100%", opacity: 0.4 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "100%", opacity: 0 }}
            transition={{ type: "spring", stiffness: 280, damping: 32 }}
            className="relative w-full sm:max-w-3xl max-h-[100vh] sm:max-h-[92vh] overflow-y-auto scrollbar-thin bg-card border-t sm:border border-white/10 sm:rounded-3xl shadow-2xl"
          >
            {/* Hero banner */}
            <div className="relative overflow-hidden border-b border-white/5">
              {/* Animated grid bg */}
              <div className="absolute inset-0 bg-grid bg-grid-fade opacity-50" />
              <div className="absolute -top-10 -right-10 h-40 w-40 rounded-full bg-white/[0.06] blur-[80px] animate-glow" />
              <div className="absolute -bottom-10 -left-10 h-40 w-40 rounded-full bg-white/[0.04] blur-[80px] animate-glow" />

              {/* Close button */}
              <button
                aria-label="Tutup"
                onClick={onClose}
                className="absolute top-4 right-4 z-10 inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-black/40 text-white/80 hover:bg-black/60 backdrop-blur"
              >
                <X className="h-4 w-4" />
              </button>

              <div className="relative px-5 sm:px-8 pt-10 pb-8">
                <div className="flex items-start gap-4">
                  {/* Big icon */}
                  <motion.div
                    initial={{ scale: 0.6, opacity: 0, rotate: -10 }}
                    animate={{ scale: 1, opacity: 1, rotate: 0 }}
                    transition={{ type: "spring", stiffness: 260, damping: 18, delay: 0.1 }}
                    className="relative inline-flex h-16 w-16 sm:h-20 sm:w-20 items-center justify-center rounded-2xl bg-white text-black ring-1 ring-white/30 shadow-[0_0_60px_rgba(255,255,255,0.18)]"
                  >
                    <Icon className="h-8 w-8 sm:h-10 sm:w-10" strokeWidth={1.75} />
                    {product.featured && (
                      <span className="absolute -top-2 -right-2 inline-flex items-center gap-1 rounded-full bg-black border border-white/20 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white">
                        <Tag className="h-2 w-2" /> Populer
                      </span>
                    )}
                  </motion.div>
                  <div className="min-w-0 flex-1">
                    <motion.div
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.18 }}
                    >
                      <div className="text-[10px] uppercase tracking-[0.25em] text-white/45">
                        Produk Digital
                      </div>
                      <h1 className="mt-1 font-display text-2xl sm:text-4xl font-extrabold text-white text-layered leading-tight" style={{ letterSpacing: "-0.02em" }}>
                        {product.name}
                      </h1>
                      <p className="mt-1.5 text-sm text-white/55">
                        {product.tagline}
                      </p>
                    </motion.div>
                  </div>
                </div>

                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.28 }}
                  className="mt-4 text-sm text-white/65 leading-relaxed max-w-xl"
                >
                  {product.description}
                </motion.p>

                {/* Trust badges */}
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.34 }}
                  className="mt-4 flex flex-wrap gap-2"
                >
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] text-white/65">
                    <ShieldCheck className="h-3 w-3" /> Bergaransi
                  </span>
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] text-white/65">
                    <Clock className="h-3 w-3" /> Proses cepat
                  </span>
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] text-white/65">
                    <QrCode className="h-3 w-3" /> Bayar QRIS
                  </span>
                </motion.div>
              </div>
            </div>

            {/* Progress bar */}
            <div className="sticky top-0 z-10 bg-card/95 backdrop-blur-xl border-b border-white/5 px-5 sm:px-8 py-3">
              <div className="flex items-center gap-2 text-[11px] text-white/55">
                <StepDot active={step === "select"} done={step !== "select"} n={1} label="Pilih paket" />
                <Line active={step !== "select"} />
                <StepDot active={step === "pay"} done={step === "done"} n={2} label="Bayar QRIS" />
                <Line active={step === "done"} />
                <StepDot active={step === "done"} done={false} n={3} label="Hubungi WA" />
              </div>
            </div>

            <div className="px-5 sm:px-8 py-6">
              <AnimatePresence mode="wait">
                {/* ---------------- STEP 1: SELECT ---------------- */}
                {step === "select" && (
                  <motion.div
                    key="select"
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.25 }}
                  >
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="font-display text-lg font-semibold text-white">
                        Pilih Durasi / Paket
                      </h2>
                      <span className="text-xs text-white/45">
                        {product.variants.length} pilihan
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {product.variants.map((v, i) => {
                        const selected = variant?.label === v.label;
                        return (
                          <motion.button
                            key={v.label}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.04 * i }}
                            onClick={() => setVariant(v)}
                            className={`relative flex items-center justify-between gap-3 rounded-xl border px-4 py-4 text-left transition-all ${
                              selected
                                ? "border-white bg-white/[0.08] shadow-[0_0_30px_rgba(255,255,255,0.06)]"
                                : "border-white/8 bg-white/[0.02] hover:border-white/15"
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <span
                                className={`flex h-5 w-5 items-center justify-center rounded-full border transition-colors ${
                                  selected
                                    ? "bg-white border-white text-black"
                                    : "border-white/30 text-transparent"
                                }`}
                              >
                                <Check className="h-3 w-3" />
                              </span>
                              <div>
                                <div className="text-sm font-medium text-white">
                                  {v.label}
                                </div>
                                {v.note && (
                                  <div className="text-[11px] text-white/45 mt-0.5">
                                    {v.note}
                                  </div>
                                )}
                              </div>
                            </div>
                            <div className="font-display text-base font-semibold text-white">
                              {formatIDR(v.price)}
                            </div>
                          </motion.button>
                        );
                      })}
                    </div>

                    <motion.button
                      disabled={!variant}
                      onClick={() => setStep("pay")}
                      whileTap={{ scale: 0.98 }}
                      className="mt-6 w-full inline-flex items-center justify-center gap-2 h-12 rounded-xl bg-white text-black text-sm font-semibold hover:shadow-[0_0_40px_rgba(255,255,255,0.3)] transition-shadow disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      Lanjut ke Pembayaran
                      <ChevronRight className="h-4 w-4" />
                    </motion.button>
                  </motion.div>
                )}

                {/* ---------------- STEP 2: PAY ---------------- */}
                {step === "pay" && variant && (
                  <motion.div
                    key="pay"
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.25 }}
                  >
                    {/* Order summary */}
                    <div className="rounded-2xl border border-white/8 bg-white/[0.02] p-4 sm:p-5">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-white/55">Produk</span>
                        <span className="text-white font-medium text-right">
                          {product.name}
                        </span>
                      </div>
                      <div className="mt-2 flex items-center justify-between text-sm">
                        <span className="text-white/55">Paket</span>
                        <span className="text-white font-medium">
                          {variant.label}
                        </span>
                      </div>
                      <div className="my-3 h-px bg-white/8" />
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-white/55">Total Bayar</span>
                        <motion.span
                          key={variant.price}
                          initial={{ opacity: 0, y: 4 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="font-display text-xl sm:text-2xl font-bold text-white"
                        >
                          {formatIDR(variant.price)}
                        </motion.span>
                      </div>
                    </div>

                    {/* QRIS Box */}
                    <motion.div
                      initial={{ opacity: 0, scale: 0.96 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.15 }}
                      className="mt-4 rounded-2xl border border-white/10 bg-white p-5 sm:p-6 text-black relative overflow-hidden"
                    >
                      {/* Subtle decorative ring */}
                      <div className="absolute -top-12 -right-12 h-32 w-32 rounded-full border-2 border-black/5 ring-spin" />

                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <QrCode className="h-4 w-4" />
                          <span className="text-sm font-semibold">
                            Scan QRIS untuk Bayar
                          </span>
                        </div>
                        <span className="inline-flex items-center gap-1 rounded-full bg-black/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">
                          GPN · QRIS
                        </span>
                      </div>

                      <div className="relative mx-auto w-full max-w-[280px] aspect-square rounded-xl overflow-hidden bg-white">
                        <img
                          src="/qris/marsel-store-qris.png"
                          alt="QRIS Marsel Store Digital"
                          className="w-full h-full object-contain"
                        />
                      </div>

                      <div className="mt-3 text-center">
                        <div className="text-xs text-black/60">Merchant</div>
                        <div className="text-sm font-bold">{STORE_NAME}</div>
                        <div className="mt-1 text-[10px] text-black/50">
                          NMID · ID1026597923998 · Terminal A01
                        </div>
                      </div>

                      <div className="mt-3 flex items-center justify-center gap-1.5 text-[11px] text-black/60">
                        <ShieldCheck className="h-3.5 w-3.5" />
                        Didukung semua e-wallet &amp; m-banking
                      </div>
                    </motion.div>

                    <ol className="mt-4 space-y-1.5 text-[12px] text-white/55">
                      <li>1. Buka aplikasi e-wallet / m-banking favoritmu.</li>
                      <li>
                        2. Pilih <span className="text-white">Scan / Bayar</span> &amp; arahkan ke QRIS di atas.
                      </li>
                      <li>3. Pastikan nominal sesuai total &amp; konfirmasi pembayaran.</li>
                      <li>4. Setelah bayar, klik tombol di bawah untuk konfirmasi via WhatsApp.</li>
                    </ol>

                    <button
                      onClick={handleConfirmPayment}
                      disabled={paying}
                      className="mt-6 w-full inline-flex items-center justify-center gap-2 h-12 rounded-xl bg-white text-black text-sm font-semibold hover:shadow-[0_0_40px_rgba(255,255,255,0.3)] transition-shadow disabled:opacity-50"
                    >
                      {paying ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Memproses...
                        </>
                      ) : (
                        <>
                          Saya Sudah Bayar
                          <ChevronRight className="h-4 w-4" />
                        </>
                      )}
                    </button>
                    <button
                      onClick={() => setStep("select")}
                      className="mt-2 w-full inline-flex items-center justify-center gap-1 h-10 text-xs text-white/55 hover:text-white"
                    >
                      <ChevronLeft className="h-3.5 w-3.5" />
                      Ubah paket
                    </button>
                  </motion.div>
                )}

                {/* ---------------- STEP 3: DONE ---------------- */}
                {step === "done" && variant && (
                  <motion.div
                    key="done"
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.25 }}
                  >
                    <div className="flex flex-col items-center text-center">
                      <motion.div
                        initial={{ scale: 0.5, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ type: "spring", stiffness: 380, damping: 18 }}
                        className="relative flex h-20 w-20 items-center justify-center rounded-full bg-white text-black"
                      >
                        <CheckCheck className="h-10 w-10" />
                        <span className="absolute inset-0 rounded-full border-2 border-white/40 animate-ping" />
                      </motion.div>
                      <h3 className="mt-4 font-display text-xl font-bold text-white">
                        Pesanan Terkonfirmasi!
                      </h3>
                      <p className="mt-2 text-sm text-white/55 max-w-sm">
                        Terima kasih sudah membayar via QRIS. Hubungi admin via
                        WhatsApp di bawah untuk pengiriman akun / proses
                        pesananmu.
                      </p>
                    </div>

                    {/* Order recap */}
                    <div className="mt-6 rounded-2xl border border-white/8 bg-white/[0.02] p-4 sm:p-5">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-white/55">Produk</span>
                        <span className="text-white font-medium">{product.name}</span>
                      </div>
                      <div className="mt-2 flex items-center justify-between text-sm">
                        <span className="text-white/55">Paket</span>
                        <span className="text-white font-medium">{variant.label}</span>
                      </div>
                      <div className="mt-2 flex items-center justify-between text-sm">
                        <span className="text-white/55">Total</span>
                        <span className="text-white font-medium">
                          {formatIDR(variant.price)}
                        </span>
                      </div>
                      <div className="my-3 h-px bg-white/8" />
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-white/45">Status</span>
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-2.5 py-1 text-[11px] font-semibold text-white">
                          <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" />
                          Menunggu konfirmasi admin
                        </span>
                      </div>
                    </div>

                    {/* WhatsApp CTA */}
                    <a
                      href={waLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-5 w-full inline-flex items-center justify-center gap-2 h-14 rounded-xl bg-white text-black text-base font-semibold hover:shadow-[0_0_40px_rgba(255,255,255,0.3)] transition-shadow"
                    >
                      <MessageCircle className="h-5 w-5" />
                      Kirim Pesanan ke WhatsApp
                      <ArrowRight className="h-4 w-4" />
                    </a>
                    <p className="mt-2 text-center text-[11px] text-white/45">
                      Pesan sudah otomatis diisi dengan detail produk &amp; harga.
                    </p>

                    <button
                      onClick={copyOrderId}
                      className="mt-3 w-full inline-flex items-center justify-center gap-1.5 h-9 text-xs text-white/55 hover:text-white"
                    >
                      {copied ? (
                        <>
                          <CheckCheck className="h-3.5 w-3.5" />
                          ID pesanan disalin!
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5" />
                          Salin ID pesanan
                        </>
                      )}
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function StepDot({
  active,
  done,
  n,
  label,
}: {
  active: boolean;
  done: boolean;
  n: number;
  label: string;
}) {
  return (
    <div className="flex items-center gap-1.5">
      <span
        className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold transition-colors ${
          done || active ? "bg-white text-black" : "border border-white/15 text-white/40"
        }`}
      >
        {done ? <Check className="h-3 w-3" /> : n}
      </span>
      <span
        className={`hidden sm:inline ${active || done ? "text-white" : "text-white/40"}`}
      >
        {label}
      </span>
    </div>
  );
}

function Line({ active }: { active: boolean }) {
  return (
    <span
      className={`flex-1 h-px transition-colors ${
        active ? "bg-white" : "bg-white/10"
      }`}
    />
  );
}
