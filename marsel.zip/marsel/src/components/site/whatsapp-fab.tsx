"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X, ChevronRight } from "lucide-react";
import { STORE_NAME, whatsappLink } from "@/lib/products";

export function WhatsAppFab() {
  const [visible, setVisible] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 240);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const link = whatsappLink(
    `Halo ${STORE_NAME}, saya melihat website dan ingin bertanya tentang produk yang tersedia.`,
  );

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, scale: 0.5, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.5, y: 30 }}
          transition={{ type: "spring", stiffness: 380, damping: 22 }}
          className="fixed bottom-5 right-5 z-40"
        >
          <div className="relative">
            {/* Pulsing ring */}
            <span className="absolute inset-0 rounded-full bg-white/30 animate-ping opacity-50" />
            <span className="absolute -inset-1 rounded-full border border-white/20 animate-bob" />

            <button
              onClick={() => setOpen((v) => !v)}
              aria-label="Hubungi WhatsApp"
              className="relative inline-flex h-14 w-14 items-center justify-center rounded-full bg-white text-black shadow-[0_8px_30px_rgba(0,0,0,0.5)] hover:scale-105 transition-transform"
            >
              {open ? (
                <X className="h-6 w-6" />
              ) : (
                <MessageCircle className="h-6 w-6" />
              )}
            </button>

            {/* Tooltip pill (always shown when closed) */}
            <AnimatePresence>
              {!open && (
                <motion.span
                  initial={{ opacity: 0, x: 8 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 8 }}
                  transition={{ delay: 0.3 }}
                  className="absolute right-16 top-1/2 -translate-y-1/2 whitespace-nowrap rounded-full border border-white/10 bg-black/80 backdrop-blur px-3 py-1.5 text-xs text-white/85 pointer-events-none hidden sm:inline-flex"
                >
                  Butuh bantuan? Chat admin
                </motion.span>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {open && (
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="absolute bottom-16 right-0 w-72 rounded-2xl border border-white/10 bg-card p-4 shadow-2xl"
                >
                  <div className="text-xs uppercase tracking-wider text-white/40">
                    Butuh bantuan?
                  </div>
                  <div className="mt-1 font-display text-sm font-semibold text-white">
                    Admin Marsel Store
                  </div>
                  <p className="mt-1 text-xs text-white/55 leading-relaxed">
                    Kami siap bantu pilih produk yang tepat &amp; proses
                    pesananmu. Klik tombol di bawah untuk chat langsung.
                  </p>
                  <a
                    href={link}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => setOpen(false)}
                    className="mt-3 inline-flex items-center justify-center gap-2 w-full h-10 rounded-lg bg-white text-black text-xs font-semibold hover:shadow-[0_0_24px_rgba(255,255,255,0.25)] transition-shadow"
                  >
                    <MessageCircle className="h-4 w-4" />
                    Chat WhatsApp
                    <ChevronRight className="h-3 w-3" />
                  </a>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
