"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { CATEGORIES, PRODUCTS } from "@/lib/products";

function makeWelcomeLines() {
  const lines = [
    "Selamat datang di Marsel Digital Store.",
    "Silakan pilih produk yang ingin kalian beli. Di sini banyak produk digital yang kami sediakan.",
  ];

  for (const category of CATEGORIES) {
    const names = PRODUCTS.filter((product) => product.category === category.id).map(
      (product) => product.name,
    );
    if (names.length) {
      lines.push(`Kategori ${category.label}. Produk yang tersedia antara lain: ${names.join(", ")}.`);
    }
  }

  lines.push("Terima kasih sudah berkunjung ke Marsel Digital Store. Selamat berbelanja!");
  return lines;
}

export function WelcomeVoice() {
  const [speaking, setSpeaking] = useState(false);
  const [supported, setSupported] = useState(false);
  const hasAutoAttempted = useRef(false);
  const utterances = useRef<SpeechSynthesisUtterance[]>([]);

  const stopWelcome = useCallback(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    utterances.current = [];
    setSpeaking(false);
  }, []);

  const playWelcome = useCallback(() => {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();

    const voices = window.speechSynthesis.getVoices();
    const indonesianVoice = voices.find((voice) => voice.lang.toLowerCase().startsWith("id"));
    const lines = makeWelcomeLines();
    const queue = lines.map((line, index) => {
      const utterance = new SpeechSynthesisUtterance(line);
      utterance.lang = "id-ID";
      utterance.rate = 0.92;
      utterance.pitch = 1;
      utterance.volume = 1;
      if (indonesianVoice) utterance.voice = indonesianVoice;
      utterance.onstart = () => setSpeaking(true);
      if (index === lines.length - 1) {
        utterance.onend = () => setSpeaking(false);
        utterance.onerror = () => setSpeaking(false);
      }
      return utterance;
    });
    utterances.current = queue;
    setSpeaking(true);
    queue.forEach((utterance) => window.speechSynthesis.speak(utterance));
  }, []);

  useEffect(() => {
    const available = "speechSynthesis" in window;
    setSupported(available);
    if (!available || hasAutoAttempted.current) return;
    hasAutoAttempted.current = true;

    // Try automatic welcome. Some browsers block speech until the visitor interacts.
    const timer = window.setTimeout(() => {
      try {
        playWelcome();
      } catch {
        setSpeaking(false);
      }
    }, 900);
    return () => window.clearTimeout(timer);
  }, [playWelcome]);

  if (!supported) return null;

  return (
    <div className="fixed bottom-5 left-4 z-[60]">
      <button
        type="button"
        onClick={speaking ? stopWelcome : playWelcome}
        aria-label={speaking ? "Hentikan suara sambutan" : "Putar suara sambutan"}
        title={speaking ? "Hentikan suara sambutan" : "Putar ulang suara sambutan"}
        className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-black/80 px-4 py-3 text-xs font-semibold text-white shadow-lg backdrop-blur-xl transition hover:bg-black"
      >
        {speaking ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        {speaking ? "Hentikan suara" : "Putar sambutan"}
      </button>
    </div>
  );
}
