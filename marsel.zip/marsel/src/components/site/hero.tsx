"use client";

import { useEffect, useRef } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import {
  ShieldCheck,
  Zap,
  Headphones,
  QrCode,
  ArrowDown,
  Sparkles,
  Star,
} from "lucide-react";
import { STORE_NAME, PRODUCTS } from "@/lib/products";
import { BRAND_NAMES } from "@/lib/icons";
import { CountUp } from "./count-up";

// Total products actually sold — derived from catalog
const TOTAL_PRODUCTS = PRODUCTS.length;

const STATS = [
  { label: "Produk Aktif", value: TOTAL_PRODUCTS, suffix: "" },
  { label: "Transaksi", value: 99, suffix: "+" },
  { label: "Rating", value: 4.9, suffix: "/5", decimals: 1 },
  { label: "Respon", value: 5, suffix: " mnt" },
];

const FEATURES = [
  {
    icon: Zap,
    title: "Proses Cepat",
    desc: "Mayoritas pesanan diproses 5–30 menit setelah pembayaran.",
  },
  {
    icon: ShieldCheck,
    title: "Garansi Resmi",
    desc: "Setiap pembelian bergaransi sesuai masa aktif produk.",
  },
  {
    icon: Headphones,
    title: "Dukungan 24/7",
    desc: "Admin siap bantu via WhatsApp kapan saja.",
  },
  {
    icon: QrCode,
    title: "QRIS Lengkap",
    desc: "Bayar dengan QRIS — semua e-wallet & m-banking.",
  },
];

export function Hero() {
  const heroRef = useRef<HTMLDivElement>(null);
  const mx = useMotionValue(50);
  const my = useMotionValue(50);
  const sx = useSpring(mx, { stiffness: 60, damping: 20 });
  const sy = useSpring(my, { stiffness: 60, damping: 20 });
  const glowX = useTransform(sx, (v) => `${v}%`);
  const glowY = useTransform(sy, (v) => `${v}%`);

  useEffect(() => {
    const el = heroRef.current;
    if (!el) return;
    const onMove = (e: MouseEvent) => {
      const rect = el.getBoundingClientRect();
      mx.set(((e.clientX - rect.left) / rect.width) * 100);
      my.set(((e.clientY - rect.top) / rect.height) * 100);
    };
    el.addEventListener("mousemove", onMove);
    return () => el.removeEventListener("mousemove", onMove);
  }, [mx, my]);

  return (
    <section
      id="top"
      ref={heroRef}
      className="relative pt-28 pb-16 sm:pt-36 sm:pb-24 overflow-hidden min-h-[88vh] flex flex-col justify-center"
    >
      {/* Local mouse-following spotlight (desktop) */}
      <motion.div
        className="pointer-events-none absolute inset-0 -z-10 hidden sm:block"
        style={{
          background: useTransform(
            [glowX, glowY],
            ([x, y]) =>
              `radial-gradient(600px circle at ${x} ${y}, rgba(255,255,255,0.08), transparent 60%)`,
          ),
        }}
      />

      {/* Slow-rotating conic ring decoration (desktop) */}
      <div className="pointer-events-none absolute -top-32 -right-32 h-96 w-96 hidden lg:block -z-10">
        <div className="absolute inset-0 rounded-full conic-ring slow-spin opacity-40" />
      </div>
      <div className="pointer-events-none absolute -bottom-40 -left-40 h-[28rem] w-[28rem] hidden lg:block -z-10">
        <div className="absolute inset-0 rounded-full conic-ring slow-spin opacity-25" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex justify-center"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] backdrop-blur px-3.5 py-1.5 text-xs sm:text-sm text-white/80">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white/60 opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-white" />
            </span>
            Online &amp; melayani 24 jam
            <span className="hidden sm:inline-flex items-center gap-0.5 text-amber-200/80 ml-1">
              <Star className="h-3 w-3 fill-current" />
              4.9
            </span>
          </span>
        </motion.div>

        {/* Heading — layered + glow + aurora sweep */}
        <motion.h1
          initial="hidden"
          animate="show"
          variants={{
            hidden: {},
            show: { transition: { staggerChildren: 0.1, delayChildren: 0.05 } },
          }}
          className="mt-6 sm:mt-8 text-center font-display font-extrabold tracking-tight"
        >
          <motion.span
            variants={{
              hidden: { opacity: 0, y: 28, clipPath: "inset(0 0 100% 0)" },
              show: {
                opacity: 1,
                y: 0,
                clipPath: "inset(0 0 0% 0)",
                transition: { duration: 0.9, ease: [0.22, 1, 0.36, 1] },
              },
            }}
            className="block text-[2rem] leading-[1.05] sm:text-6xl lg:text-8xl text-aurora text-layered"
            style={{ letterSpacing: "-0.02em" }}
          >
            {STORE_NAME}
          </motion.span>

          {/* Subtitle with animated underline */}
          <motion.span
            variants={{
              hidden: { opacity: 0, y: 16 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] },
              },
            }}
            className="mt-4 block text-xl sm:text-3xl lg:text-4xl text-white/85 relative w-fit mx-auto"
            style={{ letterSpacing: "-0.01em" }}
          >
            <span className="relative inline-block">
              Premium Digital Subscription
              <span className="absolute -bottom-1 left-0 right-0 h-[3px] rounded-full bg-gradient-to-r from-transparent via-white to-transparent underline-grow" />
            </span>
          </motion.span>
        </motion.h1>

        {/* Subheading */}
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.42 }}
          className="mt-5 mx-auto max-w-2xl text-center text-sm sm:text-lg text-white/55 text-balance px-2"
        >
          Editing APK, AI tools, streaming film &amp; musik, VPN, IMEI unlock,
          dan Robux — semua dalam satu toko. Bayar via QRIS, diproses cepat oleh
          admin terpercaya.
        </motion.p>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-8 flex flex-wrap items-center justify-center gap-3"
        >
          <a
            href="#produk"
            className="group inline-flex items-center gap-2 h-12 px-6 rounded-xl bg-white text-black text-sm font-semibold hover:shadow-[0_0_40px_rgba(255,255,255,0.35)] transition-all hover:-translate-y-0.5 active:scale-95"
          >
            Lihat Katalog
            <ArrowDown className="h-4 w-4 transition-transform group-hover:translate-y-0.5" />
          </a>
          <a
            href="#cara-pesan"
            className="inline-flex items-center gap-2 h-12 px-6 rounded-xl border border-white/15 bg-white/5 text-white text-sm font-semibold hover:bg-white/10 transition-all active:scale-95"
          >
            <Sparkles className="h-4 w-4" />
            Cara Pemesanan
          </a>
        </motion.div>

        {/* Stats — count up */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.58 }}
          className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-4"
        >
          {STATS.map((s) => (
            <div
              key={s.label}
              className="relative rounded-2xl border border-white/5 bg-white/[0.02] backdrop-blur p-4 sm:p-5 text-center overflow-hidden group hover:border-white/15 transition-colors"
            >
              <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/40 to-transparent" />
              {/* corner glow */}
              <div className="absolute -top-4 -right-4 h-12 w-12 rounded-full bg-white/[0.06] blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="font-display text-2xl sm:text-3xl font-extrabold text-white text-layered">
                {s.decimals ? (
                  <CountUp to={s.value} decimals={s.decimals} />
                ) : (
                  <CountUp to={s.value} suffix={s.suffix} />
                )}
              </div>
              <div className="mt-1 text-[10px] sm:text-xs uppercase tracking-wider text-white/45">
                {s.label}
              </div>
            </div>
          ))}
        </motion.div>

        {/* Marquee of brand names */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="mt-12 relative"
        >
          <div className="text-center text-[10px] uppercase tracking-[0.25em] text-white/35 mb-3">
            Mendukung semua aplikasi populer
          </div>
          <div className="relative overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_15%,black_85%,transparent)]">
            <div className="flex w-max animate-marquee gap-3">
              {[...BRAND_NAMES, ...BRAND_NAMES].map((name, i) => (
                <span
                  key={i}
                  className="inline-flex items-center gap-2 rounded-full border border-white/8 bg-white/[0.02] px-4 py-2 text-sm text-white/65 whitespace-nowrap"
                >
                  <span className="h-1 w-1 rounded-full bg-white/40" />
                  {name}
                </span>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Features */}
        <div className="mt-12 grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
          {FEATURES.map((f, i) => {
            const Icon = f.icon;
            return (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }}
                className="group relative rounded-2xl border border-white/5 bg-white/[0.02] p-4 sm:p-5 hover:border-white/15 hover:bg-white/[0.04] transition-all overflow-hidden shine-sweep"
              >
                <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-white group-hover:bg-white group-hover:text-black group-hover:scale-110 transition-all duration-300">
                  <Icon className="h-5 w-5" strokeWidth={1.75} />
                </div>
                <h3 className="mt-3 font-display text-sm font-semibold text-white">
                  {f.title}
                </h3>
                <p className="mt-1 text-xs text-white/55 leading-relaxed">
                  {f.desc}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
