"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search, LayoutGrid, ChevronRight } from "lucide-react";
import {
  PRODUCTS,
  CATEGORIES,
  type Product,
  type CategoryId,
} from "@/lib/products";
import { CATEGORY_ICON } from "@/lib/icons";
import { CategoryTabs } from "./category-tabs";
import { ProductCard } from "./product-card";
import { ProductDetailPage } from "./product-detail-page";

function parseHashCategory(hash: string): CategoryId | "all" {
  const m = hash.match(/^#cat-(.+)$/);
  if (!m) return "all";
  const id = m[1] as CategoryId;
  return CATEGORIES.some((c) => c.id === id) ? id : "all";
}

export function Catalog() {
  const [active, setActive] = useState<CategoryId | "all">("all");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Product | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    const sync = () => {
      const id = parseHashCategory(window.location.hash);
      setActive(id);
    };
    sync();
    window.addEventListener("hashchange", sync);
    return () => window.removeEventListener("hashchange", sync);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return PRODUCTS.filter((p) => {
      const inCat = active === "all" || p.category === active;
      const inQuery =
        q === "" ||
        p.name.toLowerCase().includes(q) ||
        p.tagline.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q);
      return inCat && inQuery;
    });
  }, [active, query]);

  const handleBuy = (p: Product) => {
    setSelected(p);
    setModalOpen(true);
  };

  const handleTabChange = (id: CategoryId | "all") => {
    setActive(id);
    if (id === "all") {
      history.replaceState(null, "", "#produk");
    } else {
      history.replaceState(null, "", `#cat-${id}`);
    }
  };

  const currentCat = CATEGORIES.find((c) => c.id === active);
  const CurrentCatIcon = currentCat ? CATEGORY_ICON[currentCat.id] : LayoutGrid;

  return (
    <section id="produk" className="relative scroll-mt-16">
      <CategoryTabs active={active} onChange={handleTabChange} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Section header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] text-white/45">
              <span className="h-1 w-1 rounded-full bg-white/40" />
              Katalog Produk
            </div>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold text-white text-layered flex items-center gap-3" style={{ letterSpacing: "-0.02em" }}>
              {currentCat ? (
                <>
                  <CurrentCatIcon className="h-6 w-6 text-white/70" strokeWidth={1.75} />
                  {currentCat.label}
                </>
              ) : (
                <>
                  <LayoutGrid className="h-6 w-6 text-white/70" strokeWidth={1.75} />
                  Semua Produk
                </>
              )}
            </h2>
            {currentCat && (
              <p className="mt-1 text-sm text-white/50">{currentCat.blurb}</p>
            )}
          </div>

          {/* Search */}
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Cari produk — CapCut, Netflix, ChatGPT..."
              className="w-full h-11 pl-10 pr-4 rounded-xl border border-white/8 bg-white/[0.03] text-sm text-white placeholder:text-white/40 focus:border-white/20 focus:bg-white/[0.05] outline-none transition-colors"
            />
          </div>
        </div>

        {/* Result count */}
        <div className="mb-4 text-xs text-white/45 flex items-center gap-2">
          <ChevronRight className="h-3 w-3" />
          {filtered.length} produk tersedia
        </div>

        {/* Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4"
        >
          <AnimatePresence mode="popLayout">
            {filtered.map((p, i) => (
              <ProductCard key={p.id} product={p} onBuy={handleBuy} index={i} />
            ))}
          </AnimatePresence>
        </motion.div>

        {filtered.length === 0 && (
          <div className="py-20 text-center">
            <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl border border-white/8 bg-white/[0.02] text-white/40">
              <Search className="h-6 w-6" />
            </div>
            <p className="mt-4 text-sm text-white/55">
              Tidak ada produk yang cocok. Coba kata kunci lain.
            </p>
          </div>
        )}
      </div>

      <ProductDetailPage
        product={selected}
        open={modalOpen}
        onClose={() => setModalOpen(false)}
      />
    </section>
  );
}
