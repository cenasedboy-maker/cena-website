"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, MessageCircle, ChevronRight } from "lucide-react";
import { STORE_NAME, whatsappLink } from "@/lib/products";
import { Magnetic } from "./magnetic";

const NAV_LINKS = [
  { label: "Produk", href: "#produk" },
  { label: "Cara Pesan", href: "#cara-pesan" },
  { label: "Kontak", href: "#kontak" },
];

const CATEGORY_LINKS = [
  { label: "Editing", href: "#cat-editing" },
  { label: "AI", href: "#cat-ai" },
  { label: "Streaming", href: "#cat-streaming" },
  { label: "VPN", href: "#cat-vpn" },
  { label: "Robux", href: "#cat-robux" },
  { label: "IMEI", href: "#cat-imei" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled
          ? "backdrop-blur-xl bg-background/70 border-b border-white/5"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="h-16 flex items-center justify-between gap-4">
          {/* Logo — user uploaded brand image */}
          <a href="#top" className="flex items-center gap-3 shrink-0 group">
            <span className="relative inline-flex h-10 w-10 items-center justify-center rounded-xl overflow-hidden ring-1 ring-white/15 shadow-[0_0_24px_rgba(255,255,255,0.12)] transition-transform group-hover:scale-105">
              <img
                src="/marsel-logo.png"
                alt="Marsel Store Digital logo"
                className="w-full h-full object-cover"
              />
              <span className="absolute inset-0 ring-1 ring-inset ring-white/20 rounded-xl pointer-events-none" />
            </span>
            <div className="flex flex-col leading-tight">
              <span className="font-display font-bold text-[13px] tracking-wide text-white">
                MARSEL STORE
              </span>
              <span className="text-[10px] uppercase tracking-[0.25em] text-white/45">
                Digital
              </span>
            </div>
          </a>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="relative px-3 py-2 text-sm text-white/70 hover:text-white rounded-md transition-colors hover:bg-white/5 group"
              >
                {link.label}
                <span className="absolute left-3 right-3 -bottom-0.5 h-px bg-white/40 scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300" />
              </a>
            ))}
            <span className="mx-1 h-5 w-px bg-white/10" />
            {CATEGORY_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="px-2.5 py-2 text-xs text-white/55 hover:text-white rounded-md transition-colors hover:bg-white/5"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Magnetic strength={0.3} className="hidden sm:block">
              <a
                href={whatsappLink(
                  `Halo ${STORE_NAME}, saya ingin bertanya tentang produk digital yang tersedia.`,
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 h-10 px-4 rounded-xl bg-white text-black text-sm font-semibold hover:shadow-[0_0_30px_rgba(255,255,255,0.25)] transition-shadow"
              >
                <MessageCircle className="h-4 w-4" />
                Pesan Sekarang
                <ChevronRight className="h-3.5 w-3.5" />
              </a>
            </Magnetic>

            <button
              type="button"
              aria-label="Toggle menu"
              className="lg:hidden inline-flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 text-white/80 hover:bg-white/10"
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="lg:hidden overflow-hidden bg-background/95 backdrop-blur-xl border-t border-white/5"
          >
            <nav className="max-w-7xl mx-auto px-4 py-3 flex flex-col gap-1">
              {NAV_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="px-3 py-2.5 text-sm text-white/80 hover:text-white rounded-md hover:bg-white/5"
                >
                  {link.label}
                </a>
              ))}
              <div className="mt-2 grid grid-cols-3 gap-1.5">
                {CATEGORY_LINKS.map((link) => (
                  <a
                    key={link.href}
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="px-2 py-2 text-xs text-white/65 hover:text-white rounded-md hover:bg-white/5 text-center border border-white/8"
                  >
                    {link.label}
                  </a>
                ))}
              </div>
              <a
                href={whatsappLink(
                  `Halo ${STORE_NAME}, saya ingin bertanya tentang produk digital yang tersedia.`,
                )}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setOpen(false)}
                className="mt-3 inline-flex items-center justify-center gap-2 h-11 rounded-lg bg-white text-black text-sm font-semibold"
              >
                <MessageCircle className="h-4 w-4" />
                Pesan via WhatsApp
              </a>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
