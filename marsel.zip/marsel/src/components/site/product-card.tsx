"use client";

import { useRef, useState } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { ArrowUpRight, Tag } from "lucide-react";
import { type Product } from "@/lib/products";
import { getProductIcon } from "@/lib/icons";

type Props = {
  product: Product;
  onBuy: (product: Product) => void;
  index?: number;
};

export function ProductCard({ product, onBuy, index = 0 }: Props) {
  const ref = useRef<HTMLButtonElement>(null);
  const Icon = getProductIcon(product.id, product.category);

  // 3D tilt
  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const srx = useSpring(rx, { stiffness: 200, damping: 18 });
  const sry = useSpring(ry, { stiffness: 200, damping: 18 });
  const rotateX = useTransform(srx, (v) => `${v}deg`);
  const rotateY = useTransform(sry, (v) => `${v}deg`);

  const [hovered, setHovered] = useState(false);

  const onMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    ry.set(px * 8);
    rx.set(-py * 8);
  };

  const onLeave = () => {
    rx.set(0);
    ry.set(0);
    setHovered(false);
  };

  return (
    <motion.button
      layout
      ref={ref}
      onMouseMove={onMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={onLeave}
      onClick={() => onBuy(product)}
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.3, delay: Math.min(index * 0.025, 0.18) }}
      style={{ rotateX, rotateY, transformPerspective: 800 }}
      className="group relative text-left flex flex-col rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.04] to-white/[0.01] p-4 sm:p-5 hover:border-white/20 hover:shadow-[0_20px_60px_-20px_rgba(0,0,0,0.7)] transition-colors overflow-hidden shine-sweep"
    >
      {product.featured && (
        <span className="absolute top-3 right-3 inline-flex items-center gap-1 rounded-full bg-white/10 border border-white/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white backdrop-blur">
          <Tag className="h-2.5 w-2.5" /> Populer
        </span>
      )}

      {/* Icon */}
      <div className="relative inline-flex">
        <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-white/10 text-white ring-1 ring-white/10 group-hover:bg-white group-hover:text-black group-hover:scale-110 transition-all duration-300">
          <Icon className="h-6 w-6" strokeWidth={1.75} />
        </div>
        {/* glow under icon on hover */}
        <motion.div
          aria-hidden
          className="absolute inset-0 rounded-xl bg-white blur-xl"
          animate={{ opacity: hovered ? 0.18 : 0 }}
          transition={{ duration: 0.3 }}
        />
      </div>

      <h3 className="mt-4 font-display text-sm sm:text-base font-semibold text-white leading-tight">
        {product.name}
      </h3>
      <p className="text-[11px] sm:text-xs text-white/45 mt-0.5">
        {product.tagline}
      </p>

      <p className="mt-3 text-xs text-white/55 leading-relaxed line-clamp-2">
        {product.description}
      </p>

      {/* Footer: pilihan paket count + CTA */}
      <div className="mt-auto pt-4 flex items-center justify-between gap-3">
        <div className="flex flex-col">
          <span className="text-[10px] uppercase tracking-wider text-white/35">
            {product.variants.length} pilihan paket
          </span>
          <span className="text-[11px] text-white/55">
            Hari · Minggu · Bulan · Tahun
          </span>
        </div>
        <span className="inline-flex items-center gap-1 h-9 px-4 rounded-lg bg-white text-black text-xs font-semibold transition-all group-hover:shadow-[0_0_24px_rgba(255,255,255,0.25)] active:scale-95">
          Beli
          <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </span>
      </div>
    </motion.button>
  );
}
