import type { Metadata } from "next";
import { Inter, Bricolage_Grotesque } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const bricolage = Bricolage_Grotesque({
  variable: "--font-display",
  subsets: ["latin"],
  display: "swap",
  weight: ["400", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: "MARSEL STORE DIGITAL — Premium Digital Subscription",
  description:
    "MARSEL STORE DIGITAL - Premium digital store untuk editing APK, AI tools, streaming film, VPN, IMEI unlock, dan Robux. Bayar via QRIS, proses cepat & terpercaya.",
  keywords: [
    "Marsel Store",
    "Marsel Store Digital",
    "CapCut",
    "Canva",
    "ChatGPT",
    "Netflix",
    "Spotify",
    "Robux",
    "QRIS",
    "Subscription Digital",
  ],
  authors: [{ name: "Marsel Store Digital" }],
  openGraph: {
    title: "MARSEL STORE DIGITAL",
    description: "Premium digital subscription store. Bayar QRIS, proses cepat.",
    siteName: "Marsel Store Digital",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" className="dark" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${bricolage.variable} font-sans antialiased bg-background text-foreground overflow-x-hidden`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
