import { Header } from "@/components/site/header";
import { Hero } from "@/components/site/hero";
import { Catalog } from "@/components/site/catalog";
import { HowToOrder } from "@/components/site/how-to-order";
import { Footer } from "@/components/site/footer";
import { WhatsAppFab } from "@/components/site/whatsapp-fab";
import { GlobalBackground } from "@/components/site/global-background";
import { WelcomeVoice } from "@/components/site/welcome-voice";

export default function Home() {
  return (
    <div className="relative min-h-screen flex flex-col bg-background text-foreground">
      {/* Fixed global animated background — visible throughout the site */}
      <GlobalBackground />
      <Header />
      <main className="relative flex-1">
        <Hero />
        <Catalog />
        <HowToOrder />
      </main>
      <Footer />
      <WhatsAppFab />
      <WelcomeVoice />
    </div>
  );
}
